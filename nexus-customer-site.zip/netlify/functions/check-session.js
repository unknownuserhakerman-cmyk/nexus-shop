// Put check-session function here
