// Put validate-key function here
